package com.example.enddaystorehouse;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    private Button b1,b2,b3;
    private MyDatabaseHelper dbhelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        b1=findViewById(R.id.b1);
        b2=findViewById(R.id.b2);
        b3=findViewById(R.id.b3);
        b1.setOnClickListener(this);
        b2.setOnClickListener(this);
        b3.setOnClickListener(this);
        dbhelper=new MyDatabaseHelper(this,"storage.db",null,1);
    }

    @Override
    public void onClick(View v){
        switch (v.getId()){
            case R.id.b1:
                Intent intentb1=new Intent(MainActivity.this, StoreActivity.class);
                startActivity(intentb1);
                break;
            case R.id.b2:
                Intent intentb2=new Intent(MainActivity.this, NoteActivity.class);
                startActivity(intentb2);
                break;

            case R.id.b3:
                Intent intentb3=new Intent(MainActivity.this, ShowActivity.class);
                startActivity(intentb3);
                break;

            default:
                break;
        }
    }
}
