package com.example.enddaystorehouse;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

public class MyDatabaseHelper extends SQLiteOpenHelper{
    public static final String createFoodList="create table food ("
            +"name text primary key,"
            +"num integer)";

    public static final String createDrinkList="create table drink ("
            +"name text primary key,"
            +"num integer)";

    public static final String createClothesList="create table clothes ("
            +"name text primary key,"
            +"num integer)";

    public static final String createMedicineList="create table medicine ("
            +"name text primary key,"
            +"num integer)";

    public static final String createEntertainmentList="create table entertainment ("
            +"name text primary key,"
            +"num integer)";

    public static final String createToolList="create table tool ("
            +"name text primary key,"
            +"num integer)";

    private Context mContext;

    public MyDatabaseHelper(Context context, String name, SQLiteDatabase.CursorFactory factory, int version){
        super(context,name,factory,version);
        mContext=context;
    }

    @Override
    public void onCreate(SQLiteDatabase db){
        db.execSQL(createFoodList);
        db.execSQL(createDrinkList);
        db.execSQL(createClothesList);
        db.execSQL(createMedicineList);
        db.execSQL(createEntertainmentList);
        db.execSQL(createToolList);
        Toast.makeText(mContext,"Create successd",Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onUpgrade(SQLiteDatabase db,int oldVersion, int newVersion){

    }

}
