package com.example.enddaystorehouse;

public class Item {
    private String name;
    private int num;

    public Item(String na, int nu){
        this.name=na;
        this.num=nu;
    }

    public String getName() {
        return name;
    }

    public int getNum() {
        return num;
    }
}
