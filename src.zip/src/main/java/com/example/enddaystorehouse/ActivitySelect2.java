package com.example.enddaystorehouse;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class ActivitySelect2 extends AppCompatActivity {

    private TextView tv;
    private MyDatabaseHelper dbhelper;
    private List<Item> list=new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_select2);
        dbhelper=new MyDatabaseHelper(this,"storage.db",null,1);
        String t=getIntent().getStringExtra("table");
        String n=getIntent().getStringExtra("name");
        initlist(t,n);
        ItemAdapter adapter=new ItemAdapter(ActivitySelect2.this,R.layout.itemlayout,list);
        ListView listView=findViewById(R.id.select2listview);
        listView.setAdapter(adapter);
        tv=findViewById(R.id.select2tv);
        if (t.equals("clothes")) t="衣服";
        else if(t.equals("drink")) t="饮料";
        else if(t.equals("medicine")) t="医药消毒";
        else if(t.equals("entertainment")) t="娱乐";
        else if(t.equals("tool")) t="工具及其他";
        else t="食物";
        tv.setText(t);
    }

    private void initlist(String t, String n){
        SQLiteDatabase db=dbhelper.getWritableDatabase();
        //String sql="select * from "+t+" where name = "+n;
        //Cursor cursor=db.rawQuery(sql,null);
        Cursor cursor=db.query(t,null,null,null,null,null,null);
        while(cursor.moveToNext()){
            String name=cursor.getString(cursor.getColumnIndex("name"));
            if (name.equals(n)) {
                int num = cursor.getInt(cursor.getColumnIndex("num"));
                Item i = new Item(name, num);
                list.add(i);
            }
        }
        cursor.close();
    }

}
