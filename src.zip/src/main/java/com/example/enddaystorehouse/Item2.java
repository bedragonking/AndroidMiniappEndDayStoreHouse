package com.example.enddaystorehouse;

public class Item2 {
    private String t,name,num;

    public Item2(String ty,String na, String nu){
        this.t=ty;
        this.name=na;
        this.num=nu;
    }

    public String getT() {
        return t;
    }

    public String getName() {
        return name;
    }

    public String getNum() {
        return num;
    }
}
