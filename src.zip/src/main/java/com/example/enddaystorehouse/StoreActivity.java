package com.example.enddaystorehouse;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.Gravity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Date;

public class StoreActivity extends AppCompatActivity implements View.OnClickListener{

    private Button b21,b22,b23,b24,b25,b26;
    private EditText e1,e2,e3,e4;
    private Spinner sp1,sp2,sp3,sp4;
    private ArrayAdapter<String> adapter;
    private String t1,t2,t3,t4;
    private TextView tv;
    private MyDatabaseHelper dbhelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_store);
        b21=findViewById(R.id.b21);
        b22=findViewById(R.id.b22);
        b23=findViewById(R.id.b23);
        b24=findViewById(R.id.b24);
        b25=findViewById(R.id.b25);
        b26=findViewById(R.id.b26);
        e1=findViewById(R.id.e1);
        e2=findViewById(R.id.e2);
        e3=findViewById(R.id.e3);
        e4=findViewById(R.id.e4);
        sp1=findViewById(R.id.sp1);
        sp2=findViewById(R.id.sp2);
        sp3=findViewById(R.id.sp3);
        sp4=findViewById(R.id.sp4);
        tv=findViewById(R.id.tv26);
        t1="food";
        t2="food";
        t3="food";
        t4="food";

        b21.setOnClickListener(this);
        b22.setOnClickListener(this);
        b23.setOnClickListener(this);
        b24.setOnClickListener(this);
        b25.setOnClickListener(this);
        b26.setOnClickListener(this);

        String[] typeAr={"食物","饮料","衣服","医药消毒","娱乐","工具及其他"};
        adapter=new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,typeAr);
        sp1.setAdapter(adapter);
        sp2.setAdapter(adapter);
        sp3.setAdapter(adapter);
        sp4.setAdapter(adapter);

        sp1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                TextView t=(TextView) view;
                t.setTextSize(21);
                t.setGravity(Gravity.CENTER);
                t1=parent.getItemAtPosition(position).toString();
                if (t1.equals("衣服")) t1="clothes";
                else if(t1.equals("饮料")) t1="drink";
                else if(t1.equals("医药消毒")) t1="medicine";
                else if(t1.equals("娱乐")) t1="entertainment";
                else if(t1.equals("工具及其他")) t1="tool";
                else t1="food";
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
        sp2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                TextView t=(TextView) view;
                t.setTextSize(13);
                t.setGravity(Gravity.CENTER);
                t2=parent.getItemAtPosition(position).toString();
                if (t2.equals("衣服")) t2="clothes";
                else if(t2.equals("饮料")) t2="drink";
                else if(t2.equals("医药消毒")) t2="medicine";
                else if(t2.equals("娱乐")) t2="entertainment";
                else if(t2.equals("工具及其他")) t2="tool";
                else t2="food";
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
        sp3.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                TextView t=(TextView) view;
                t.setTextSize(13);
                t.setGravity(Gravity.CENTER);
                t3=parent.getItemAtPosition(position).toString();
                if (t3.equals("衣服")) t3="clothes";
                else if(t3.equals("饮料")) t3="drink";
                else if(t3.equals("医药消毒")) t3="medicine";
                else if(t3.equals("娱乐")) t3="entertainment";
                else if(t3.equals("工具及其他")) t3="tool";
                else t3="food";
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
        sp4.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                TextView t=(TextView) view;
                t.setTextSize(13);
                t.setGravity(Gravity.CENTER);
                t4=parent.getItemAtPosition(position).toString();
                if (t4.equals("衣服")) t4="clothes";
                else if(t4.equals("饮料")) t4="drink";
                else if(t4.equals("医药消毒")) t4="medicine";
                else if(t4.equals("娱乐")) t4="entertainment";
                else if(t4.equals("工具及其他")) t4="tool";
                else t4="food";
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });

        dbhelper=new MyDatabaseHelper(this,"storage.db",null,1);
        new Time().start();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.b21:
                Intent intentb21=new Intent(StoreActivity.this, ActivitySelect.class);
                intentb21.putExtra("table",t1);
                startActivity(intentb21);
                break;

            case R.id.b22:
                String name1=e1.getText().toString();
                if (name1.equals("")){
                    Toast.makeText(StoreActivity.this,"输入不完整！",Toast.LENGTH_SHORT).show();
                }else{
                    Intent intentb22=new Intent(StoreActivity.this, ActivitySelect2.class);
                    intentb22.putExtra("table",t2);
                    intentb22.putExtra("name",name1);
                    startActivity(intentb22);
                }
                break;

            case R.id.b23:
                String name2=e2.getText().toString();
                String snum=e3.getText().toString();
                if (name2.equals("")||snum.equals("")){
                    Toast.makeText(StoreActivity.this,"输入不完整！",Toast.LENGTH_SHORT).show();
                }else{
                    int f=0;
                    for (int i=0;i<snum.length();i++){
                        if (!Character.isDigit(snum.charAt(i)))
                            f=1;
                    }
                    if (f==1){
                        Toast.makeText(StoreActivity.this,"输入数量不全是数字！",Toast.LENGTH_SHORT).show();
                    }else{
                        int num=Integer.parseInt(snum);
                        SQLiteDatabase db=dbhelper.getWritableDatabase();
                        ContentValues values=new ContentValues();
                        values.put("name",name2);
                        values.put("num",num);
                        db.insert(t3,null,values);
                        values.clear();
                        Toast.makeText(StoreActivity.this,"增加成功！",Toast.LENGTH_SHORT).show();
                    }
                }
                break;

            case R.id.b24:
                String name22=e2.getText().toString();
                String snum2=e3.getText().toString();
                if (name22.equals("")||snum2.equals("")){
                    Toast.makeText(StoreActivity.this,"输入不完整！",Toast.LENGTH_SHORT).show();
                }else{
                    int f=0;
                    for (int i=0;i<snum2.length();i++){
                        if (!Character.isDigit(snum2.charAt(i)))
                            f=1;
                    }
                    if (f==1){
                        Toast.makeText(StoreActivity.this,"输入数量不全是数字！",Toast.LENGTH_SHORT).show();
                    }else{
                        int num2=Integer.parseInt(snum2);
                        SQLiteDatabase db=dbhelper.getWritableDatabase();
                        ContentValues values=new ContentValues();
                        values.put("num",num2);
                        db.update(t3,values,"name=?",new String[]{name22});
                        values.clear();
                        Toast.makeText(StoreActivity.this,"完成！",Toast.LENGTH_SHORT).show();
                    }
                }
                break;

            case R.id.b25:
                String name4=e4.getText().toString();
                if (name4.equals("")){
                    Toast.makeText(StoreActivity.this,"输入不完整！",Toast.LENGTH_SHORT).show();
                }else{
                    SQLiteDatabase db=dbhelper.getWritableDatabase();
                    db.delete(t4,"name=?",new String[]{name4});
                    Toast.makeText(StoreActivity.this,"已删除！",Toast.LENGTH_SHORT).show();
                }
                break;

            case R.id.b26:
                AlertDialog.Builder d=new AlertDialog.Builder(StoreActivity.this);
                d.setTitle("警告～～");
                d.setMessage("确定清空全部物资？");
                d.setCancelable(false);
                d.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        SQLiteDatabase db=dbhelper.getWritableDatabase();
                        db.execSQL("delete from food");
                        db.execSQL("delete from drink");
                        db.execSQL("delete from clothes");
                        db.execSQL("delete from medicine");
                        db.execSQL("delete from entertainment");
                        db.execSQL("delete from tool");
                        Toast.makeText(StoreActivity.this,"已删除！",Toast.LENGTH_SHORT).show();
                    }
                });
                d.setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                    }
                });
                d.show();
                break;

            default:
                break;
        }
    }


    public class Time extends Thread{
        @Override
        public void run() {
            super.run();
            do{
                try {
                    Thread.sleep(1000);
                    Message msg=new Message();
                    msg.what=1;
                    handler.sendMessage(msg);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }while (true);
        }
    }

    private Handler handler=new Handler(new Handler.Callback() {
        @Override
        public boolean handleMessage(Message msg) {
            switch (msg.what){
                case 1:
                    tv.setText(new SimpleDateFormat("yyyy-MM-dd  hh:mm:ss").format(new Date()));
                    break;

                default:
                    break;
            }
            return false;
        }
    });
}
