package com.example.enddaystorehouse;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.List;

public class Item2Adapter extends ArrayAdapter<Item2>{
    private int resourseid;

    public Item2Adapter(Context context, int textViewResourseid, List<Item2> objects){
        super(context,textViewResourseid,objects);
        resourseid=textViewResourseid;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent){
        Item2 i=getItem(position);
        View view= LayoutInflater.from(getContext()).inflate(resourseid,parent,false);
        TextView ty=view.findViewById(R.id.typename);
        ty.setText(i.getT());
        TextView name=view.findViewById(R.id.itemname);
        name.setText(i.getName());
        TextView num=view.findViewById(R.id.itemnum);
        String temp=i.getNum();
        String t=""+temp;
        num.setText(t);
        return view;
    }
}
