package com.example.enddaystorehouse;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.List;

public class ItemAdapter extends ArrayAdapter<Item>{
    private int resourseid;

    public ItemAdapter(Context context, int textViewResourseid, List<Item> objects){
        super(context,textViewResourseid,objects);
        resourseid=textViewResourseid;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent){
        Item i=getItem(position);
        View view= LayoutInflater.from(getContext()).inflate(resourseid,parent,false);
        TextView name=view.findViewById(R.id.itemname);
        name.setText(i.getName());
        TextView num=view.findViewById(R.id.itemnum);
        int temp=i.getNum();
        String t=""+temp;
        num.setText(t);
        return view;
    }
}
