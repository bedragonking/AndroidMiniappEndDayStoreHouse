package com.example.enddaystorehouse;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

public class ShowActivity extends AppCompatActivity {

    private List<Item2> list=new ArrayList<>();
    private MyDatabaseHelper dbhelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show);
        dbhelper=new MyDatabaseHelper(this,"storage.db",null,1);
        initlist();

        Item2Adapter adapter=new Item2Adapter(ShowActivity.this,R.layout.item2layout,list);
        ListView listView=findViewById(R.id.shwolistview);
        listView.setAdapter(adapter);
    }

    private void initlist(){
        SQLiteDatabase db=dbhelper.getWritableDatabase();
        Cursor c1=db.query("food",null,null,null,null,null,null);
        Cursor c2=db.query("drink",null,null,null,null,null,null);
        Cursor c3=db.query("clothes",null,null,null,null,null,null);
        Cursor c4=db.query("medicine",null,null,null,null,null,null);
        Cursor c5=db.query("entertainment",null,null,null,null,null,null);
        Cursor c6=db.query("tool",null,null,null,null,null,null);

        list.add(new Item2("食物","",""));
        while(c1.moveToNext()){
            String name=c1.getString(c1.getColumnIndex("name"));
            int num=c1.getInt(c1.getColumnIndex("num"));
            Item2 i=new Item2("",name,Integer.toString(num));
            list.add(i);
        }
        c1.close();

        list.add(new Item2("","",""));
        list.add(new Item2("饮料","",""));

        while(c2.moveToNext()){
            String name=c2.getString(c2.getColumnIndex("name"));
            int num=c2.getInt(c2.getColumnIndex("num"));
            Item2 i=new Item2("",name,Integer.toString(num));
            list.add(i);
        }
        c2.close();

        list.add(new Item2("","",""));
        list.add(new Item2("衣服","",""));
        while(c3.moveToNext()){
            String name=c3.getString(c3.getColumnIndex("name"));
            int num=c3.getInt(c3.getColumnIndex("num"));
            Item2 i=new Item2("",name,Integer.toString(num));
            list.add(i);
        }
        c3.close();

        list.add(new Item2("","",""));
        list.add(new Item2("医药消毒","",""));
        while(c4.moveToNext()){
            String name=c4.getString(c4.getColumnIndex("name"));
            int num=c4.getInt(c4.getColumnIndex("num"));
            Item2 i=new Item2("",name,Integer.toString(num));
            list.add(i);
        }
        c4.close();

        list.add(new Item2("","",""));
        list.add(new Item2("娱乐","",""));
        while(c5.moveToNext()){
            String name=c5.getString(c5.getColumnIndex("name"));
            int num=c5.getInt(c5.getColumnIndex("num"));
            Item2 i=new Item2("",name,Integer.toString(num));
            list.add(i);
        }
        c5.close();

        list.add(new Item2("","",""));
        list.add(new Item2("工具及其他","",""));
        while(c6.moveToNext()){
            String name=c6.getString(c6.getColumnIndex("name"));
            int num=c6.getInt(c6.getColumnIndex("num"));
            Item2 i=new Item2("",name,Integer.toString(num));
            list.add(i);
        }
        c6.close();
    }
}
